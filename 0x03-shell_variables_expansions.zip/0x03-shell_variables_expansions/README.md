Shell Expansion scripts
